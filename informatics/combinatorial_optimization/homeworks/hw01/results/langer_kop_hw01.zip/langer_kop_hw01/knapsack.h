#pragma once

#ifdef __cplusplus
extern "C" {
#endif

double solve(int method, const char *file_in, const char *file_out);

#ifdef __cplusplus
}
#endif
