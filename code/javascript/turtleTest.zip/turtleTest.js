// CANVAS
var canvas = document.getElementById('cnvs');
var context = canvas.getContext('2d');
[canvas.width, canvas.height] = [window.innerWidth, window.innerHeight];
canvas.style.backgroundColor = 'yellow';

// SUBFUNCTIONS
context.drawLine = function(x0, y0, x1, y1){
    this.beginPath();
    this.moveTo(x0, y0);
    //console.log(this);
    this.lineTo(x1, y1);
    this.stroke();
}

// TURTLE
const Turtle = function(ctx, h=90, x=window.innerWidth/2, y=window.innerHeight/2){
    this.canvas = ctx.canvas;
    [this.X, this.Y] = [x, y];
    this.heading = Math.PI*h/180;
    this.penIsDown = true;

    this.forward = function(length){
        //console.log("leng, thisX, tY,", length, this.X, this.Y);
        newX = this.X + length*Math.cos(this.heading);
        newY = this.Y - length*Math.sin(this.heading);
        //console.log("newX, newY,", newX, newY);
        ctx.drawLine(this.X, this.Y, newX, newY);
        [this.X, this.Y] = [newX, newY];
    };

    this.left = function(deg){
        this.heading = this.heading + Math.PI*deg/180;
    };

    this.right = function(deg){
        this.heading = this.heading - Math.PI*deg/180;
    };

    this.penup = function(){
        this.penIsDown = false;
    };
    this.pendown = function(){
        this.penIsDown = true;
    };
    this.setposition = function(x, y){
        [this.X, this.Y] = [x, y];
    };
    this.setheading = function(h){
        this.heading = h;
    };
};

// L-SYSTEMS

var viewPlant = function(s, step, angle){
    var len = s.length;
    this.stack = [];

    for (k = 0; k < len; k++) {
        switch (s.charAt(k)) {
            case 'F':
                //console.log('case F');
                t.forward(step);
                break;
            case '-':
                t.left(angle);
                break;
            case '+':
                t.right(angle);
                break;
            case '[':
                this.stack.push([[t.X, t.Y],t.heading])
                //stack.append((t.pos(), t.heading()));
                break;
            case ']':
                [p, h] = this.stack.pop();
                t.penup();
                t.setposition(p[0], p[1]);
                t.setheading(h);
                t.pendown();
                /*/
                (p,h) = stack.pop();
                t.penup();
                t.setposition(p);
                t.setheading(h);
                t.pendown();
                /*/
                break;
            default:
                //console.log('switch char: ', s.charAt(k));
        }
    }
}

var plant = function(ch){
    switch(ch) {
        case 'X':
            return 'F+[[X]-X]-F[-FX]+X'
        case 'F':
            return 'FF'
        default:
            return ch;
    }
}

var getNextGen = function(sP){
    var sN = '';
    //console.log('sP ', sP);
    var len = sP.length;
    //console.log('len ', len);
    length
    for (j = 0; j < len; j++) { 
        chN = plant(sP.charAt(j));
        //console.log("getN, loop| len, i, chN", len, j, chN);
        sN += chN;
    }
    return sN;
}

// MAIN
const step_length = 1;
const turn_angle = 25;
const start_angle = 145;
var t = new Turtle(context, start_angle, window.innerWidth*(9/10), window.innerHeight*(19/20));
    
var s = 'X';
var gens = 9;
var i;
for (i = 0; i < gens; i++) { 
    //console.log('loop beg, i:', i);
    s = getNextGen(s);
    //console.log('loop bef if, i:', i);
    if (i == gens-1) {
        //console.log('if (i == gens-1)');
        //console.log('s: ', s);
        viewPlant(s, step_length, turn_angle);
    }
    //console.log('after if | i, gens-1', i, gens-1);
}

context.strokeStyle = 'blue';

/*/
var a = [];
a.push("added")
console.log(a);
a.pop();
console.log(a);


turtle.forward(100);
turtle.forward(100);
turtle.forward(100);
turtle.left(90);
turtle.forward(100);
turtle.right(130);
turtle.forward(100);
/*/


/*/
//[window.prevX, window.prevY] = [window.innerWidth/2, window.innerHeight/2];
context.drawLine(50, 50, 400, 400);
context.drawLine(20, 20, 300, 300);
/*/
